<!DOCTYPE>
<html>
<head>
    <meta http-equiv="Content-Style-Type" content="text/css" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="format-detection" content="telephone=no"/>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="/favicon.ico">
    <link rel="stylesheet" href="/style/css/bootstrap.min.css" type="text/css" />
	<script src="/style/js/jquery.min.js"></script>
	<script src="/style/js/bootstrap.min.js"></script>
</head>
<body>
<?
$password = '1231';
$secretkey = hash('sha256', $password);;
?>